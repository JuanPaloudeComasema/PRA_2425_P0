#include <iostream>
#include "BrazoRobotico.c++"


main(){
	int main() {
    // Crear una instancia de BrazoRobotico
    BrazoRobotico brazo;

    // Mover el brazo a una nueva posición
    brazo.mover(10.0, 20.0, 30.0);
    std::cout << "Posición del brazo: (" << brazo.getX() << ", " << brazo.getY() << ", " << brazo.getZ() << ")\n";

    // Coger un objeto
    brazo.coger();
    std::cout << "Objeto recogido y preparado para traslado ";

    return 0;
